To run this demo, please install cv2 first. 
(http://www.mobileway.net/2015/02/14/install-opencv-for-python-on-mac-os-x/)



For the algorithm part, there is a detailed explaination, you may want to have a look.(http://www.pyimagesearch.com/2014/12/01/complete-guide-building-image-search-engine-python-opencv/) 



For GUI part, you can do more 
~

Basically, this demo only use color histogram features which is stored in "index.csv". 

You can generate this file by running "index.py". 

To build a more powerful search engine, you can write your own "index.py" to generate better feature representation file "index.csv".

Good luck~
